package com.example;

        import java.awt.Toolkit;
        import java.io.BufferedReader;
        import java.io.BufferedWriter;
        import java.io.File;
        import java.io.FileInputStream;
        import java.io.FileOutputStream;
        import java.io.IOException;
        import java.io.InputStreamReader;
        import java.io.OutputStreamWriter;
        import javax.swing.JFileChooser;
        import javax.swing.JOptionPane;

 public    class TekstKonwerterCyfryUsun {


    public static void konwertuj(FileInputStream fis ,FileOutputStream fos) throws IOException {
        String in_enc  = "Cp1250";
        String out_enc  = "UTF8";
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(fis, in_enc));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(fos, out_enc));
            String line;

            while ((line = in.readLine()) != null) {
                out.write(line);
                out.newLine();                               // zapis znaku końca wiersza
            }
            in.close();
            out.close();
        }
        catch (IOException e) {
            System.err.println(e);

        }
    }
    public static void konwertuj2(File from ,File to) throws IOException {
        String in_enc  = "Cp1250";
        String out_enc  = "Cp1250";
        try {

            FileInputStream fis = new FileInputStream(from);
            BufferedReader in = new BufferedReader(new InputStreamReader(fis, in_enc));
            FileOutputStream fos = new FileOutputStream(to);
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(fos, out_enc));
            String line;

            while ((line = in.readLine()) != null) {
                long zlicziloraz=1;
                int zliczsume=0;

                for (int i=0;i<line.length();i++){    //oblicza wartosci slowa
                    zlicziloraz*=line.charAt(i);  /////// mnozenie dla linii
                    zliczsume+=line.charAt(i);
                }
                //	sumkontr+=line.charAt(i);
                //	sumkontr*=line.length();

                out.write(line + "|" + (zlicziloraz + zliczsume));
                //		out.write( "|" + line.charAt(i) *10);
                out.newLine();                               // zapis znaku końca wiersza
            }
            in.close();
            out.close();
        }
        catch (IOException e) {
            System.err.println(e);
        }
    }

    public static void konwertuj3(File from ,File to) throws IOException {
        String in_enc  = "Cp1250";
        String out_enc  = "Cp1250";
        try {
            FileInputStream fis = new FileInputStream(from);
            BufferedReader in = new BufferedReader(new InputStreamReader(fis, in_enc));
            FileOutputStream fos = new FileOutputStream(to);
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(fos, out_enc));
            String line;
            int idx =0;
            while ((line = in.readLine()) != null) {

                for (int i=0;i<line.length();i++){
                    if (line.charAt(i) >= '0' && line.charAt(i) <= '9' && i > 2 || line.charAt(i) == '/' )
                        ;
                    else{
                        out.write(line.charAt(i));
                                        }
                }
                out.newLine();
            }
            in.close();
            out.close();
        }
        catch (IOException e) {
            System.err.println(e);
        }
    }

    // gdy wywolanie z nazwą pliku  #############
    public static void main(String[] args) throws IOException {
        if (args.length == 1) {
            File in = new File(args[0]);
            File out = new File(args[0]  + ".o.txt");

            konwertuj2(in, out);  /// --------------

            Toolkit.getDefaultToolkit().beep();
            JOptionPane.showMessageDialog(null, "Gotowe ;)");
            JOptionPane.showMessageDialog(null, "Wynik w pliku *.out.txt");
            System.exit(0);
        }
        //////////////######################################################3
        // gdy wywolanie bez pliku
        if (args.length == 0) {
            JOptionPane.showMessageDialog(null, "Program wycina wszystkie cyfry z pliku oraz znak / \n" +
                    "zaczynajac od 3 znaku od lewej, polskie znaki - Cp1250, \n" +
                            "autor: Szczepan Panek 2016 r."
            );
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Wybierz plik.");

            int result = chooser.showOpenDialog(null);
            if (result != JFileChooser.APPROVE_OPTION){
                return;
            }
            File in = chooser.getSelectedFile();             //
            //      result = chooser.showSaveDialog(null);
            if (result != JFileChooser.APPROVE_OPTION){
                return;
            }
            //      File out = chooser.getSelectedFile();				// wybiera po raz drugi plik
            String   	dir = "" +	chooser.getSelectedFile();

            File out = new File(dir + ".out.txt");
            konwertuj3(in, out);
            Toolkit.getDefaultToolkit().beep();
            //    JOptionPane.showMessageDialog(null, "Gotowe ;)");
            JOptionPane.showMessageDialog(null, "Wynik w pliku *.out.txt");
        }
    }
}