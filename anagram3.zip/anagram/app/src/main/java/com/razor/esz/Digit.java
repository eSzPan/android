package com.razor.esz;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class Digit extends Activity implements OnClickListener
{
	EditText txtWlasne;
	EditText txtDlugosc;
	int dlugosc,licz,licznik,liczpetla,supermax=0;
	StringBuffer buffer=new StringBuffer();
	Button btnAdd,btnDelete,btnCzysc,btnKzN,btnViewAll,btnSzukaj,
			btnKopiujBaze,btnZakoncz,btnTest,btnP1;
	//ImageButton btnCancel;
	SQLiteDatabase db;
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main2);

		txtWlasne=(EditText)findViewById(R.id.txtWla);
		txtDlugosc=(EditText)findViewById(R.id.txtDlug);

		btnSzukaj=(Button)findViewById(R.id.btnSzukaj);
		btnSzukaj.setOnClickListener(this);

		btnKzN=(Button)findViewById(R.id.btnKzN);
		btnKzN.setOnClickListener(this);

		btnViewAll=(Button)findViewById(R.id.btnViewAll);
		btnViewAll.setOnClickListener(this);

		btnKopiujBaze=(Button)findViewById(R.id.btnKopiujBaze);
		btnKopiujBaze.setOnClickListener(this);

		//btnCancel=(Button)findViewById(R.id.btnCzysc);
		//btnCancel.setOnClickListener(this);

		btnZakoncz=(Button)findViewById(R.id.btnZakoncz);
		btnZakoncz.setOnClickListener(this);


		db=openOrCreateDatabase("slowa.DB", Context.MODE_WORLD_WRITEABLE, null);
		db.execSQL("CREATE TABLE IF NOT EXISTS slowa(literki VARCHAR, cyferki VARCHAR);");
	//	db.execSQL("DROP TABLE if exists " + "slowa");
//		db.execSQL("CREATE TABLE IF NOT EXISTS slowa(literki VARCHAR, cyferki VARCHAR);");
//		db.execSQL("INSERT INTO slowa VALUES('aa','9603');");
//		db.execSQL("INSERT INTO slowa VALUES('aah','978834');");
//		db.execSQL("INSERT INTO slowa VALUES('aahs','112532053');");
//		db.execSQL("INSERT INTO slowa VALUES('aas','1082344');");

	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.trzykropki, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		int id = item.getItemId();

		switch (id){
			case R.id.pod_baz:
				btnViewAll.performClick();
				break;
			case R.id.imp_baz:
				btnKopiujBaze.performClick();
				break;
			case R.id.pomoc:
				showMessage("", this.getString(R.string.pomoc));
				break;
			case R.id.wersja:
				Toast.makeText(this,"Version 2.0\nautor Szczepan Panek\n2018 r.",Toast.LENGTH_LONG).show();
				break;
		}
		return true;

	}
	public void onClick1(View view){ txtWlasne.append("_");
	}

	public void onClick2(View view) { txtWlasne.append("%");
	}

	public void onClick3(View view) { clearText();
	}

	public void onClick(View view) {

		///////////////////////////////////////////////////////////////*********
		if (view == btnKzN)            // K z N permutacja
		{
			Permutacjakzn kzn = new Permutacjakzn();
			buffer.setLength(0);

			if (txtWlasne.getText().toString().trim().length() == 0) {
				showMessage("Error", "Wprowadź tekst");
				return;
			}

			if (txtDlugosc.getText().toString().trim().length() == 0) {
				txtDlugosc.setText("" + txtWlasne.length());
				int ile = Integer.parseInt(txtDlugosc.getText().toString());
				buffer.setLength(0);
				licz = 0;
				pusto(ile);
				return;
			}

			int ile = Integer.parseInt(txtDlugosc.getText().toString());


			String[] arr = kzn.string2Arr(txtWlasne.getText().toString().trim());
			int dlugoscTabeliWynikow =  kzn.silnia_iter(arr.length)/(kzn.silnia_iter(ile) * kzn.silnia_iter(arr.length-ile));
			String [] wynik = new String[dlugoscTabeliWynikow];
			kzn.combinationsKzN(arr,ile, 0, new String[ile],wynik);
			String dopolecenia = "SELECT * FROM slowa where cyferki = '123'" ;
			for (String s:wynik) {
				dopolecenia = dopolecenia.concat(" or cyferki = '");
				dopolecenia = dopolecenia.concat("" + kzn.obliczSumKontr(s));
				dopolecenia = dopolecenia.concat("'");
			}
			Cursor c = db.rawQuery(dopolecenia, null);
			/////////////////////////////////
			if (c.getCount() == 0) {
				showMessage("Brak rekordów", "w bazie");
			}
			////////////////////////////
			licz = 0;
			while (c.moveToNext()) {
				buffer.append(c.getString(0) +"\t\t" + obliczSumPunktow(c.getString(0)) + "\n");
				licz++;
			}

			if (buffer.toString().trim().length() > 0)
				showMessage("Znaleziono \t" + licz  , buffer.toString() + "\n");

			txtDlugosc.setText("");	// na koncu czysci dlugosc
		}
		///////////////////////////////////////////////////////////////*********


		if (view == btnViewAll) {

			Cursor c = db.rawQuery("SELECT * FROM slowa limit 100", null);
			/////////////////////////////////
			if (c.getCount() == 0) {
				showMessage("Brak rekordów", " w bazie");

			}
			////////////////////////////
			StringBuffer buffer = new StringBuffer();
			while (c.moveToNext()) {
				buffer.append("l: \t" + c.getString(0) + "\n");
				//buffer.append(" c: "+c.getString(1)+"\n");
			}
			showMessage("Baza danych", buffer.toString());
		}


		if (view == btnKopiujBaze) {
			//	showMessage("Scrabble anagram", "Developed By RazoR-eSz");
			copyDataBaseFromSdCard();
			//	copyBase2FromSdCard();
		}

		if (view == btnCzysc) {
			clearText();
		}


		if (view == btnZakoncz) {
			//	 finish();
			//	Toast tost = Toast.makeText(getApplicationContext(), "Pomysł, projekt i kodowanie\nPanek Szczepan 2017 v 3.0", Toast.LENGTH_LONG);
			//	tost.show();
			finish();
		}
		///////////////////////////////////////////////////////////////*********
		if (view == btnSzukaj)            // Szukanie
		{
			buffer.setLength(0);
			licz = 0;

			if (txtWlasne.getText().toString().trim().length() == 0)        //jezeli txtWlasne pusty to powrót
			{
				showMessage("", " tekst:\n% zast. wszystkie znaki,\n _ zast. poj znak\n np: m_d_a albo m%");
				return;
			}
			//jezeli txtWlasne pełne i tablica pełna
			if (txtWlasne.getText().toString().trim().length() != 0) {
				String Tekst = txtWlasne.getText().toString().trim();
				//long sumKontr = obliczSumKontr(Tekst);
				try {
					//	dlugosc = txtWlasne.getText().toString().length();  //oblicza z podanych liter
					//	Cursor c=db.rawQuery("SELECT * FROM slowa where literki like '" +txtWlasne.getText().toString().trim()+"%' AND length(literki) =" + dlugosc, null);
					//Cursor c=db.rawQuery("SELECT * FROM slowa where literki like '" +txtWlasne.getText().toString().trim()+ "'", null);
					Cursor c = db.rawQuery("SELECT * FROM slowa where literki like '" + Tekst + "'", null);
					/////////////////////////////////
					if (c.getCount() == 0) {
						showMessage("Brak rekordów 1", "w bazie");
						return;
					}
					////////////////////////////
					// licz=0;
					while (c.moveToNext()) {
						buffer.append(c.getString(0) + "\t\t" + obliczSumPunktow(c.getString(0)) + "\n");
						licz++;
					}

					if (buffer.toString().trim().length() > 0)
						showMessage("Znalazłem: " + licz, buffer.toString());
				} catch (Exception e) {
					showMessage("błąd", " nr1");
				}
			}
		}

///////////////////////////////////////////////////////////////*********
	}
	public void pusto(int dl){
		int ile =dl;
		Permutacjakzn kzn = new Permutacjakzn();


		if (txtWlasne.getText().toString().trim().length() == 0) {
			showMessage("Error", "Wprowadź tekst");
			return;
		}


		String[] arr = kzn.string2Arr(txtWlasne.getText().toString().trim());
		int dlugoscTabeliWynikow =  kzn.silnia_iter(arr.length)/(kzn.silnia_iter(ile) * kzn.silnia_iter(arr.length-ile));
		String [] wynik = new String[dlugoscTabeliWynikow];
		kzn.combinationsKzN(arr,ile, 0, new String[ile],wynik);
		String dopolecenia = "SELECT * FROM slowa where cyferki = '123'" ;
		for (String s:wynik) {
			dopolecenia = dopolecenia.concat(" or cyferki = '");
			dopolecenia = dopolecenia.concat("" + kzn.obliczSumKontr(s));
			dopolecenia = dopolecenia.concat("'");
		}
		Cursor c = db.rawQuery(dopolecenia, null);
		/////////////////////////////////
//		if (c.getCount() == 0) {
//			showMessage("Brak rekordów", "w bazie");
//		}
		////////////////////////////

		while (c.moveToNext()) {
			buffer.append(c.getString(0) +"\t\t" + obliczSumPunktow(c.getString(0)) + "\n");
			licz++;
		}



		if (ile <= 2) {
				txtDlugosc.setText("");	// na koncu czysci dlugosc

			if (buffer.toString().trim().length() > 0)
				showMessage("Znaleziono \t" + licz  , buffer.toString() + "\n");

			return ;
		}
		else
			 pusto(ile-1);


	}

	public void showMessage(String title,String message)
	{
		Builder builder=new Builder(this);
		builder.setCancelable(true);
		builder.setTitle(title);
		builder.setMessage(message);
		builder.show();
	}

	public long obliczSumKontr(String slowo){

		long zlicziloraz=1;
		int zliczsume=0;

		for (int i=0;i<slowo.length();i++)   //oblicza wartosci slowa
		{
			zlicziloraz*=slowo.charAt(i); ;  /////// mnozenie dla linii
			zliczsume+=slowo.charAt(i); ;  /////// suma dla linii
		}
		return zlicziloraz + zliczsume;
	}
	class Permutacjakzn{
		public  int j=0;
		public  void combinationsKzN(String[] arr, int len, int startPosition, String[] result, String[] wyniki){

			if (len == 0){
				// wyniki[j] = Arrays.toString(result);
				wyniki[j] = arrToString(result);
				j++;
				return ;
			}
			for (int i = startPosition; i <= arr.length-len; i++){
				result[result.length - len] = arr[i];
				combinationsKzN(arr, len-1, i+1, result,wyniki);
			}

		}


		///////////////////////////////////
		public int silnia(int i)
		{
			if (i == 0)
				return 1;
			else
				return i * silnia(i - 1);
		}
		///////////////////////////////////

		///////////////////////////////////
		public int  silnia_iter(int n)
		{
			int sil=1;
			for(int i=2;i<=n;i++)
				sil = sil *i;

			return sil;
		}
		///////////////////////////////////
		///////////////////////////////////
		public String  arrToString(String[] tab)
		{
			String tekst = "";
			for(int i=0;i<tab.length;i++) {
				tekst=tekst.concat(tab[i]);
			}
			return tekst;
		}
		///////////////////////////////////

		///////////////////////////////////

		public String [] string2Arr(String str) {
			String [] lista = new String[str.length()];

			for(int i=0;i<str.length();i++) {
				lista[i] = "" +  str.charAt(i);
			}
			return lista;
		}
		///////////////////////////////////

		///////////////////////////////////
		public long obliczSumKontr(String slowo){

			long zlicziloraz=1;
			int zliczsume=0;

			for (int i=0;i<slowo.length();i++)   //oblicza wartosci slowa
			{
				zlicziloraz*=slowo.charAt(i); ;  /////// mnozenie dla linii
				zliczsume+=slowo.charAt(i); ;  /////// suma dla linii
			}
			return zlicziloraz + zliczsume;
		}
		///////////////////////////////////

	}
	public int obliczSumPunktow(String slowoscr){

		int zliczsumepkt=0;

		for (int i=0;i<slowoscr.length();i++)   //oblicza sumę punktów
		{
			switch (slowoscr.charAt(i)) {
				case 'a':
					zliczsumepkt += 1;
					break;
				case 'e':
					zliczsumepkt += 1;
					break;
				case 'i':
					zliczsumepkt += 1;
					break;
				case 'n':
					zliczsumepkt += 1;
					break;
				case 'o':
					zliczsumepkt += 1;
					break;
				case 'r':
					zliczsumepkt += 1;
					break;
				case 's':
					zliczsumepkt += 1;
					break;
				case 'w':
					zliczsumepkt += 1;
					break;
				case 'z':
					zliczsumepkt += 1;
					break;
				case 'c':
					zliczsumepkt += 2;
					break;
				case 'd':
					zliczsumepkt += 2;
					break;
				case 'k':
					zliczsumepkt += 2;
					break;
				case 'l':
					zliczsumepkt += 2;
					break;
				case 'm':
					zliczsumepkt += 2;
					break;
				case 'p':
					zliczsumepkt += 2;
					break;
				case 't':
					zliczsumepkt += 2;
					break;
				case 'y':
					zliczsumepkt += 2;
					break;
				case 'b':
					zliczsumepkt += 3;
					break;
				case 'g':
					zliczsumepkt += 3;
					break;
				case 'h':
					zliczsumepkt += 3;
					break;
				case 'j':
					zliczsumepkt += 3;
					break;
				case 'ł':
					zliczsumepkt += 3;
					break;
				case 'u':
					zliczsumepkt += 3;
					break;
				case 'ą':
					zliczsumepkt += 5;
					break;
				case 'ę':
					zliczsumepkt += 5;
					break;
				case 'f':
					zliczsumepkt += 5;
					break;
				case 'ó':
					zliczsumepkt += 5;
					break;
				case 'ś':
					zliczsumepkt += 5;
					break;
				case 'ż':
					zliczsumepkt += 5;
					break;
				case 'ć':
					zliczsumepkt += 6;
					break;
				case 'ń':
					zliczsumepkt += 7;
					break;
				case 'ź':
					zliczsumepkt += 9;
					break;

				default:
					;
			}
		}
		return  zliczsumepkt;
	}

	public void clearText()
	{
		txtWlasne.setText("");
		txtDlugosc.setText("");
		txtWlasne.requestFocus();
	}

	private void copyDataBaseFromSdCard()
	{
		try
		{
			String DB_PATH = "data/data/" + getPackageName() + "/databases/";
			String DB_NAME = "slowa.DB";
			String DB_wej_NAME = "import.DB";
			String Download = "/Download/";


			//		String yourDbFileNamePresentInSDCard = "/mnt/Download/import.DB";
			String yourDbFileNamePresentInSDCard = Environment.getExternalStorageDirectory().getPath() +Download + DB_wej_NAME;
			//	showMessage("sciezka: ",Environment.getExternalStorageDirectory().getPath()+ Download + DB_wej_NAME);
			File file = new File(yourDbFileNamePresentInSDCard);
			// Open your local db as the input stream
			InputStream myInput = new FileInputStream(file);

			// Path to created empty db
			String outFileName = DB_PATH + DB_NAME;

			// Opened assets database structure
			OutputStream myOutput = new FileOutputStream(outFileName);

			// transfer bytes from the inputfile to the outputfile
			byte[] buffer = new byte[1024];
			int length;
			while ((length = myInput.read(buffer)) > 0) {
				myOutput.write(buffer, 0, length);
			}

			// Close the streams
			myOutput.flush();
			myOutput.close();
			myInput.close();
			showMessage("Skopiowano OK", "Esz");
		}
		catch(Exception e)
		{
			String DB_PATH = "data/data/" + getPackageName() + "/databases/";
			String DB_NAME = "slowa.DB";
			String DB_wej_NAME = "import.DB";
			String Download = "/Download/";
			String yourDbFileNamePresentInSDCard = Environment.getExternalStorageDirectory().getPath() +Download + DB_wej_NAME;

			showMessage("Błąd","nie znlaeziono: " + yourDbFileNamePresentInSDCard);
		}
	}

	private SQLiteDatabase getDB()
	{
		String DB_NAME = "import.DB";
		return openOrCreateDatabase(DB_NAME, SQLiteDatabase.OPEN_READWRITE, null);
	}


	private void copyBase2SdCard()
	{
		try
		{
			String DB_PATH = "data/data/" + getPackageName() + "/databases/";
			String DB_NAME = "slowa.DB";

			String yourDbFileNamePresentInSDCard = "/mnt/sdcard/Download/2test2DB";
			File file = new File(yourDbFileNamePresentInSDCard);
			// Open your local db as the input stream
			// Path to created empty db
			String outFileName = DB_PATH + DB_NAME;
			InputStream myInput = new FileInputStream(outFileName);



			// Opened assets database structure
			OutputStream myOutput = new FileOutputStream(file);

			// transfer bytes from the inputfile to the outputfile
			byte[] buffer = new byte[1024];
			int length;
			while ((length = myInput.read(buffer)) > 0) {
				myOutput.write(buffer, 0, length);
			}

			// Close the streams
			myOutput.flush();
			myOutput.close();
			myInput.close();
			showMessage("Skopiowano OK", "Esz");
		}
		catch(Exception e)
		{
			showMessage("Błąd", "Esz");
		}
	}



	class PermutacjaAlgorytm {

		public  int j=0;

		public void doPerm(String [] perm,StringBuffer str, int index){

			if(index <= 0){
				//   System.out.println(""+ j++ + str);
				perm[j++] = str.toString();
			}
			else { //recursively solve this by placing all other chars at current first pos
				doPerm(perm,str, index-1);
				int currPos = str.length()-index;
				for (int i = currPos+1; i < str.length(); i++) {//start swapping all other chars with current first char
					swap(str,currPos, i);
					doPerm(perm,str, index-1);
					swap(str,i, currPos);//restore back my string buffer
				}
			}
		}

		private   void swap(StringBuffer str, int pos1, int pos2){
			char t1 = str.charAt(pos1);
			str.setCharAt(pos1, str.charAt(pos2));
			str.setCharAt(pos2, t1);
		}
		///////////////////////////////////
		public  int silnia(int i)
		{
			if (i == 0)
				return 1;
			else
				return i * silnia(i - 1);
		}
		///////////////////////////////////
	}

}